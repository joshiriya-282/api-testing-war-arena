const API_ORIGIN = "https://jsonplaceholder.typicode.com";
const requests = [
  { id: "list-posts", name: "List posts", method: "GET", path: "/posts", group: "CRUD", description: "Read a collection and validate its response shape.", body: "", expectations: ["Status is 200 OK", "Response is an array", "Each post contains id and title"] },
  { id: "get-post", name: "Get post by ID", method: "GET", path: "/posts/1", group: "CRUD", description: "Fetch one resource by its identifier.", body: "", expectations: ["Status is 200 OK", "Post ID equals 1", "Post title is present"] },
  { id: "create-post", name: "Create unique post", method: "POST", path: "/posts", group: "CRUD", description: "Create a uniquely tagged sandbox post on every send.", body: JSON.stringify({ title: "SPSU Placement Application", body: "Created in API Testing War Arena", userId: 101 }, null, 2), expectations: ["Status is 201 Created", "Returned title matches request", "Response contains an id"] },
  { id: "update-post", name: "Update post title", method: "PATCH", path: "/posts/1", group: "CRUD", description: "Patch one field without replacing the full resource.", body: JSON.stringify({ title: "Updated placement application" }, null, 2), expectations: ["Status is 200 OK", "Updated title is returned", "Resource ID remains 1"] },
  { id: "delete-post", name: "Delete test post", method: "DELETE", path: "/posts/1", group: "CRUD", description: "Delete a practice resource and inspect the response.", body: "", expectations: ["Status is 200 OK", "Request completed without a server error"] },
  { id: "missing-resource", name: "Unknown endpoint", method: "GET", path: "/probe_missing_resource", group: "Negative", description: "Check the sandbox behavior for an unknown resource path.", body: "", expectations: ["Status is 404 Not Found", "Response does not claim a resource was found"] }
];
let postSequence = 0;

let activeRequest = requests[0];
let activeSuite = "All";
let activeResultFilter = "All";
let resultTests = [];
let responseView = "body";
let lastResponseText = "";
let lastResponseHeaders = {};
let toastTimer;

const requestList = document.getElementById("requestList");
const requestSearch = document.getElementById("requestSearch");
const methodFilter = document.getElementById("methodFilter");
const requestBody = document.getElementById("requestBody");

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function methodClass(request) {
  return request.group === "Negative" ? "negative" : request.method.toLowerCase();
}

function renderRequests() {
  const query = requestSearch.value.trim().toLowerCase();
  const method = methodFilter.value;
  const visible = requests.filter((request) => (activeSuite === "All" || request.group === activeSuite) && (method === "All" || request.method === method) && `${request.name} ${request.path} ${request.method}`.toLowerCase().includes(query));
  requestList.innerHTML = visible.map((request) => `<button class="request-item${request.id === activeRequest.id ? " active" : ""}" type="button" role="listitem" data-request-id="${request.id}" aria-current="${request.id === activeRequest.id ? "true" : "false"}"><span class="method-mini ${methodClass(request)}">${request.method}</span><span class="request-item-copy"><strong>${escapeHTML(request.name)}</strong><small>${escapeHTML(request.path)}</small></span><i class="request-indicator"></i></button>`).join("");
  document.getElementById("requestCount").textContent = `${visible.length} / ${requests.length}`;
}

function selectRequest(request) {
  activeRequest = request;
  lastResponseText = "";
  lastResponseHeaders = {};
  document.getElementById("requestTitle").textContent = request.name;
  document.getElementById("requestDescription").textContent = request.description;
  document.getElementById("requestNumber").textContent = `${String(requests.indexOf(request) + 1).padStart(2, "0")} / ${String(requests.length).padStart(2, "0")}`;
  const method = document.getElementById("activeMethod");
  method.textContent = request.method;
  method.className = `method-pill method-${methodClass(request)}`;
  document.getElementById("activePath").textContent = request.path;
  document.getElementById("bodyTabNote").textContent = request.body ? "JSON" : "none";
  document.getElementById("assertionCount").textContent = request.expectations.length;
  requestBody.value = request.body;
  document.getElementById("expectationList").innerHTML = request.expectations.map((expectation) => `<div class="expectation-row"><i></i>${escapeHTML(expectation)}</div>`).join("");
  document.getElementById("responseTitle").textContent = "Waiting for request";
  document.getElementById("httpStatus").textContent = "--";
  document.getElementById("httpStatus").className = "http-status";
  document.getElementById("responseTime").textContent = "-- ms";
  document.getElementById("responseSize").textContent = "-- B";
  document.getElementById("responseEmpty").hidden = false;
  document.getElementById("responseOutput").hidden = true;
  document.getElementById("runSummary").textContent = "Ready to test";
  document.getElementById("runCaption").textContent = "Send this request when ready";
  resultTests = [];
  activeResultFilter = "All";
  setResultFilter("All");
  renderRequests();
}

function setResultFilter(filter) {
  activeResultFilter = filter;
  document.querySelectorAll(".result-filter").forEach((tab) => {
    const selected = tab.dataset.resultFilter === filter;
    tab.classList.toggle("active", selected);
    tab.setAttribute("aria-selected", String(selected));
  });
  renderResults();
}

function renderResults() {
  const visible = resultTests.filter((test) => activeResultFilter === "All" || test.status === activeResultFilter);
  const passed = resultTests.filter((test) => test.status === "Pass").length;
  const failed = resultTests.length - passed;
  document.getElementById("testResultCount").textContent = resultTests.length;
  document.getElementById("allResultCount").textContent = resultTests.length;
  document.getElementById("passResultCount").textContent = passed;
  document.getElementById("failResultCount").textContent = failed;
  const list = document.getElementById("testList");
  if (!resultTests.length) {
    list.innerHTML = '<div class="tests-empty">Assertions will appear here after you send a request.</div>';
    return;
  }
  if (!visible.length) {
    list.innerHTML = '<div class="tests-empty">No assertions in this filter.</div>';
    return;
  }
  list.innerHTML = visible.map((test) => `<div class="test-row"><span class="test-icon${test.status === "Fail" ? " fail" : ""}"><svg><use href="#i-check"/></svg></span><span class="test-copy">${escapeHTML(test.name)}</span><span class="test-detail">${escapeHTML(test.detail)}</span></div>`).join("");
}

function addTest(name, passed, detail) {
  resultTests.push({ name, status: passed ? "Pass" : "Fail", detail: passed ? "PASS" : detail });
}

function runAssertions(response, data, jsonError, submittedBody) {
  resultTests = [];
  const checks = {
    "list-posts": () => {
      addTest("Status is 200 OK", response.status === 200, `Expected 200, received ${response.status}`);
      addTest("Response is an array", Array.isArray(data), "Expected a JSON array");
      const shapeOK = Array.isArray(data) && data.every((post) => Number.isInteger(post.id) && typeof post.title === "string");
      addTest("Each post contains id and title", shapeOK, "Expected each item to include id and title");
    },
    "get-post": () => {
      addTest("Status is 200 OK", response.status === 200, `Expected 200, received ${response.status}`);
      addTest("Post ID equals 1", data?.id === 1, `Received ID ${data?.id ?? "none"}`);
      addTest("Post title is present", typeof data?.title === "string" && data.title.length > 0, "Expected a non-empty title");
    },
    "create-post": () => {
      addTest("Status is 201 Created", response.status === 201, `Expected 201, received ${response.status}`);
      addTest("Returned title matches request", data?.title === submittedBody?.title, "Returned title did not match the request");
      addTest("Response contains an id", data && Object.hasOwn(data, "id"), "Response did not contain an id");
    },
    "update-post": () => {
      addTest("Status is 200 OK", response.status === 200, `Expected 200, received ${response.status}`);
      addTest("Updated title is returned", data?.title === submittedBody?.title, "Updated title was not returned");
      addTest("Resource ID remains 1", data?.id === 1, `Received ID ${data?.id ?? "none"}`);
    },
    "delete-post": () => {
      addTest("Status is 200 OK", response.status === 200, `Expected 200, received ${response.status}`);
      addTest("Request completed without a server error", response.status < 500, `Server returned ${response.status}`);
    },
    "missing-resource": () => {
      addTest("Status is 404 Not Found", response.status === 404, `JSONPlaceholder returned ${response.status}; this sandbox may not model missing-resource errors`);
      addTest("Response does not claim a resource was found", response.status === 404 || (data && !Object.hasOwn(data, "id")), "An unexpected resource ID was returned");
    }
  };
  if (jsonError && activeRequest.id !== "missing-resource") {
    addTest("Response body is valid JSON", false, "Response body was not valid JSON");
  } else {
    addTest("Response body is valid JSON", !jsonError, jsonError ? "Response body was not valid JSON" : "");
  }
  checks[activeRequest.id]();
}

function formatResponse(data, jsonError, rawText) {
  if (jsonError) return rawText || "<empty response body>";
  if (data === null && !rawText) return "<empty response body>";
  return JSON.stringify(data, null, 2);
}

async function sendRequest() {
  let submittedBody = null;
  if (activeRequest.body) {
    try {
      submittedBody = JSON.parse(requestBody.value);
    } catch {
      showToast("Request body is not valid JSON.");
      requestBody.focus();
      return;
    }
  }
  if (activeRequest.id === "create-post") {
    postSequence += 1;
    const baseTitle = submittedBody.title.split(" [run ")[0];
    submittedBody.title = `${baseTitle} [run ${Date.now()}-${postSequence}]`;
    requestBody.value = JSON.stringify(submittedBody, null, 2);
  }
  const button = document.getElementById("sendButton");
  button.disabled = true;
  button.querySelector("span").textContent = "Sending...";
  document.getElementById("runSummary").textContent = "Request in progress";
  document.getElementById("runCaption").textContent = `${activeRequest.method} ${activeRequest.path}`;
  const started = performance.now();
  try {
    const response = await fetch(`${API_ORIGIN}${activeRequest.path}`, {
      method: activeRequest.method,
      headers: submittedBody ? { "Content-Type": "application/json; charset=UTF-8" } : undefined,
      body: submittedBody ? JSON.stringify(submittedBody) : undefined
    });
    lastResponseHeaders = Object.fromEntries(response.headers.entries());
    const elapsed = Math.round(performance.now() - started);
    const rawText = await response.text();
    let data = null;
    let jsonError = false;
    if (rawText) {
      try { data = JSON.parse(rawText); } catch { jsonError = true; }
    }
    lastResponseText = formatResponse(data, jsonError, rawText);
    const output = document.querySelector("#responseOutput code");
    output.textContent = lastResponseText;
    document.getElementById("responseOutput").hidden = false;
    document.getElementById("responseEmpty").hidden = true;
    document.getElementById("responseTitle").textContent = response.statusText || "Response received";
    const status = document.getElementById("httpStatus");
    status.textContent = `${response.status} ${response.statusText}`;
    status.className = `http-status${response.status < 300 ? " success" : response.status < 500 ? " client-error" : " server-error"}`;
    document.getElementById("responseTime").textContent = `${elapsed} ms`;
    document.getElementById("responseSize").textContent = `${new Blob([rawText]).size} B`;
    runAssertions(response, data, jsonError, submittedBody);
    document.getElementById("runSummary").textContent = `${resultTests.filter((test) => test.status === "Pass").length}/${resultTests.length} assertions passed`;
    document.getElementById("runCaption").textContent = `${activeRequest.method} ${activeRequest.path} complete`;
    renderResults();
    if (responseView === "headers") showHeaders(response.headers);
  } catch (error) {
    lastResponseHeaders = {};
    lastResponseText = JSON.stringify({ error: "Network request failed", message: error.message }, null, 2);
    document.querySelector("#responseOutput code").textContent = lastResponseText;
    document.getElementById("responseOutput").hidden = false;
    document.getElementById("responseEmpty").hidden = true;
    document.getElementById("responseTitle").textContent = "Network error";
    document.getElementById("httpStatus").textContent = "FETCH ERROR";
    document.getElementById("httpStatus").className = "http-status server-error";
    document.getElementById("responseTime").textContent = `${Math.round(performance.now() - started)} ms`;
    document.getElementById("responseSize").textContent = `${new Blob([lastResponseText]).size} B`;
    resultTests = [{ name: "Request reached the practice API", status: "Fail", detail: error.message }];
    document.getElementById("runSummary").textContent = "Request could not reach the API";
    document.getElementById("runCaption").textContent = "Check your connection and retry";
    renderResults();
  } finally {
    button.disabled = false;
    button.querySelector("span").textContent = "Send request";
  }
}

function showHeaders() {
  document.querySelector("#responseOutput code").textContent = JSON.stringify(lastResponseHeaders, null, 2);
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

requestList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-request-id]");
  if (button) selectRequest(requests.find((request) => request.id === button.dataset.requestId));
});
requestSearch.addEventListener("input", renderRequests);
methodFilter.addEventListener("change", renderRequests);
document.getElementById("sendButton").addEventListener("click", sendRequest);
document.getElementById("resetBody").addEventListener("click", () => { requestBody.value = activeRequest.body; showToast("Example body restored."); });
document.querySelectorAll(".editor-tab").forEach((tab) => tab.addEventListener("click", () => {
  const showTests = tab.dataset.editorTab === "tests";
  document.querySelectorAll(".editor-tab").forEach((item) => {
    const selected = item === tab;
    item.classList.toggle("active", selected);
    item.setAttribute("aria-selected", String(selected));
  });
  document.getElementById("bodyEditor").hidden = showTests;
  document.getElementById("expectations").hidden = !showTests;
}));
document.querySelectorAll(".result-filter").forEach((tab) => tab.addEventListener("click", () => setResultFilter(tab.dataset.resultFilter)));
document.querySelectorAll(".response-tab").forEach((tab) => tab.addEventListener("click", () => {
  responseView = tab.dataset.responseTab;
  document.querySelectorAll(".response-tab").forEach((item) => item.classList.toggle("active", item === tab));
  if (responseView === "body") document.querySelector("#responseOutput code").textContent = lastResponseText;
  else if (lastResponseText) showHeaders();
}));
document.getElementById("copyResponse").addEventListener("click", async () => {
  if (!lastResponseText) { showToast("No response to copy yet."); return; }
  try { await navigator.clipboard.writeText(lastResponseText); showToast("Response copied."); }
  catch { showToast("Clipboard access is unavailable in this browser."); }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "/" && document.activeElement !== requestSearch && document.activeElement !== requestBody) { event.preventDefault(); requestSearch.focus(); }
});

renderRequests();
selectRequest(activeRequest);